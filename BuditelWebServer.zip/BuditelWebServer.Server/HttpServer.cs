﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace BuditelWebServer.Server
{
	public class HttpServer
	{
		private readonly IPAddress ipAddress;
		private readonly int port;
		private readonly TcpListener serverListener;

		public HttpServer(string ipAddress, int port)
		{
			this.ipAddress = IPAddress.Parse(ipAddress);
			this.port = port;
			this.serverListener = new TcpListener(this.ipAddress,this.port);
		}

		public void Start()
		{
			this.serverListener.Start();

			Console.WriteLine($"Server started on port {port}");
			Console.WriteLine($"Listening for requests...");
			while (true)
			{
				var connection = serverListener.AcceptTcpClient();
				var networkStream = connection.GetStream();
				WriteResponse(networkStream, "Hello from the server!");
				connection.Close();
			}
		}

		private void WriteResponse(NetworkStream networkStream, string message)
		{
			int contentLength = Encoding.UTF8.GetByteCount(message);
			var response = $@"HTTP/1.1
Content-Type:text/plain; charset=UTF-8
Content-Length: {contentLength}

{message}";

			var responseBytes = Encoding.UTF8.GetBytes(response);
			networkStream.Write(responseBytes);
		}
	}
}
